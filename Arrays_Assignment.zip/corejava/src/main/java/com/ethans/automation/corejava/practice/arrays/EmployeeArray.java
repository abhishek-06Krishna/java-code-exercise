package com.ethans.automation.corejava.practice.arrays;

import java.util.Scanner;

public class EmployeeArray {

	String empid;
	String ename;
	String deptid;
	double salary;
	
	static int size;
	static EmployeeArray[] empArr = new EmployeeArray[50];
	
	
	
	

	public EmployeeArray(String empid, String ename, String deptid, double salary) {
		this.empid = empid;
		this.ename = ename;
		this.deptid = deptid;
		this.salary = salary;
	}

	/*
	 * public void declareArray() { int i,size;
	 * 
	 * System.out.println("Enter the size of the array");
	 * 
	 * size = scan.nextInt();
	 * 
	 * for (i = 0; i < size; i++) { empArr[i] = new EmployeeArray(empid, ename,
	 * dept, salary);
	 * 
	 * }
	 * 
	 * }
	 */

	public static void initializeArray() {
		
		Scanner scan =new Scanner(System.in);
		

		
		int j;
		System.out.println("Enter the size of the array");

		size =scan.nextInt();

		for (j = 0; j < size; j++) {
			System.out.println("Enter Employee Details");

			System.out.println("Enter Salary");

			double salary = scan.nextDouble();

			System.out.println("Enter Name");
			String ename = scan.next();

			System.out.println("Enter dept");

			String dept = scan.next();

			System.out.println("Enter Employee Id");

			String empid = scan.next();

			empArr[j] = new EmployeeArray(empid, ename, dept, salary);
		}
			for(j=0;j<size;j++) {
			System.out.println(empArr[j]);

			System.out.println();
			}
		

	}
	
	public static void insertNewElement() {
		
		int i, pos;
		
		Scanner scan = new Scanner(System.in);
		 
		System.out.println("At Which Position? Enter the index number");
		
		pos = scan.nextInt();
		
		for(i=size;i>pos;i--) {
			
			empArr[i]=empArr[i-1];
		}
		
		
		System.out.println("Enter Employee Details");

		System.out.println("Enter Salary");

		double salary = scan.nextDouble();

		System.out.println("Enter Name");
		String ename = scan.next();

		System.out.println("Enter dept");

		String dept = scan.next();

		System.out.println("Enter Employee Id");

		String empid = scan.next();

		empArr[pos] = new EmployeeArray(empid, ename, dept, salary);
		
		
		System.out.println("Element inserted Successfully");
		
		System.out.println("The New Array is :");
		
		//System.out.println(empArr[4]);
		for(i=0;i<size+1;i++) {
			System.out.println(empArr[i]);

			System.out.println();
			
		}
		
		
		
		
		
		
	}

	public String toString() {

		return this.deptid + "::" + this.empid + "::" + this.ename + "::" + this.salary;

	}

}