package com.ethans.automation.corejava.practice.arrays;

import java.util.Scanner;

public class EmployeeArrayTest {

	public static void main(String[] args) {
		  
		
	EmployeeArray.initializeArray();
		EmployeeArray.insertNewElement();
		
		}

	}


